import { initializeApp, FirebaseApp } from 'firebase/app';
import { 
    getFirestore,
    Firestore,
    collection, 
    writeBatch, 
    increment, 
    doc, 
    onSnapshot,
    query,
    orderBy,
    addDoc,
    setDoc,
    deleteDoc,
    getDoc,
    updateDoc
} from 'firebase/firestore';
import {
    getAuth,
    Auth,
    signInWithEmailAndPassword,
    createUserWithEmailAndPassword,
    onAuthStateChanged,
    signOut,
    User
} from 'firebase/auth';

// --- PENTING: KONFIGURASI FIREBASE ANDA ---
// 1. Buka Firebase Console > Project settings > General > Your apps > SDK setup and configuration.
// 2. Salin objek `firebaseConfig` dan tempel di bawah ini.
// 3. PENTING: Buka Build > Firestore Database, lalu klik "Create database".
//    Aplikasi ini TIDAK akan berfungsi jika database Firestore belum dibuat.
const firebaseConfig = {
  apiKey: "AIzaSyDKOYS6mY5gFSb7l-hDrso8bb71XtgJLQw",
  authDomain: "my-app-dec3d.firebaseapp.com",
  projectId: "my-app-dec3d",
  storageBucket: "my-app-dec3d.firebasestorage.app",
  messagingSenderId: "922171351724",
  appId: "1:922171351724:web:6adf077597ae60ff5b3509",
  measurementId: "G-WD9G3XQBPP"
};


let app: FirebaseApp | null = null;
let db: Firestore | null = null;
let auth: Auth | null = null;
export let isFirebaseConfigured = false;

// Cek apakah konfigurasi sudah diisi dan bukan placeholder
if (firebaseConfig.apiKey && firebaseConfig.apiKey !== "YOUR_API_KEY" && firebaseConfig.projectId && firebaseConfig.projectId !== "YOUR_PROJECT_ID") {
    try {
        app = initializeApp(firebaseConfig);
        db = getFirestore(app);
        auth = getAuth(app);
        isFirebaseConfigured = true;
    } catch (e) {
        console.error("Error initializing Firebase. Pastikan konfigurasi Anda benar.", e);
        isFirebaseConfigured = false;
    }
} else {
    // Pesan UI akan ditangani oleh App.tsx, jadi console.error di sini tidak krusial.
}


export { 
    db, 
    auth,
    collection,
    writeBatch, 
    increment,
    doc,
    onSnapshot,
    query,
    orderBy,
    addDoc,
    setDoc,
    deleteDoc,
    getDoc,
    updateDoc,
    signInWithEmailAndPassword,
    createUserWithEmailAndPassword,
    onAuthStateChanged,
    signOut,
};
export type { User };