export type Section = 'dashboard' | 'transactions' | 'ledger' | 'reconciliation' | 'assets' | 'reports' | 'settings';

export type UserRole = 'admin' | 'staff' | 'manager';
export type UserStatus = 'pending' | 'approved' | 'rejected';

export interface AppUser {
    uid: string;
    name: string;
    email: string;
    role: UserRole;
    status: UserStatus;
}

export interface Account {
    id: string;
    code: string;
    name: string;
    type: 'Aset' | 'Liabilitas' | 'Modal' | 'Pendapatan' | 'Beban';
    balance: number;
    description?: string;
    isDefault?: boolean;
}

export interface JournalEntry {
    account: string; // Account code
    debit: number;
    credit: number;
}

export interface Transaction {
    id: string;
    date: string; // ISO string
    ref: string;
    desc: string;
    entries: JournalEntry[];
}

export interface Asset {
    id: string;
    name: string;
    category: string;
    cost: number;
    date: string; // ISO string
    life: number; // in years
    residual: number;
    method: 'straight-line' | 'declining-balance' | 'sum-of-years';
    accumulatedDepreciation: number;
    isDepreciable: boolean;
}

export interface CompanySettings {
    id: string;
    name: string;
    address: string;
    phone?: string;
    email?: string;
    npwp?: string;
    businessType: string;
    currency: string;
    taxYear: string;
    periodStart: string;
    website?: string;
    owner?: string;
    description?: string;
}

export interface DataContextType {
    accounts: Account[];
    transactions: Transaction[];
    assets: Asset[];
    settings: CompanySettings | null;
    loading: boolean;
    error: string | null;
    currentUser: AppUser | null;
    users: AppUser[];
    addTransaction: (transaction: Omit<Transaction, 'id'>) => Promise<void>;
    deleteTransaction: (id: string) => Promise<void>;
    addAsset: (asset: Omit<Asset, 'id'>) => Promise<void>;
    updateAsset: (id: string, asset: Omit<Asset, 'id'>) => Promise<void>;
    deleteAsset: (id: string) => Promise<void>;
    addAccount: (account: Omit<Account, 'id' | 'balance'>) => Promise<void>;
    updateAccount: (id: string, account: Omit<Account, 'id' | 'balance'>) => Promise<void>;
    deleteAccount: (id: string) => Promise<void>;
    approveUser: (uid: string, role: UserRole) => Promise<void>;
    rejectUser: (uid: string) => Promise<void>;
    updateUserRole: (uid: string, role: UserRole) => Promise<void>;
}