import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Account, Asset, CompanySettings, DataContextType, Transaction, AppUser, UserRole } from '../types';
import { 
    db, 
    auth,
    collection,
    query,
    orderBy,
    onSnapshot,
    doc,
    writeBatch,
    increment,
    addDoc,
    setDoc,
    deleteDoc,
    getDoc,
    updateDoc,
} from '../services/firebase';

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode; appUser: AppUser }> = ({ children, appUser }) => {
    const [accounts, setAccounts] = useState<Account[]>([]);
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [assets, setAssets] = useState<Asset[]>([]);
    const [settings, setSettings] = useState<CompanySettings | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [currentUser, setCurrentUser] = useState<AppUser | null>(appUser);
    const [users, setUsers] = useState<AppUser[]>([]);
    
    useEffect(() => {
        setLoading(true);
        setError(null); 
        setCurrentUser(appUser);

        if (!db) {
            setError("Koneksi ke database tidak tersedia.");
            setLoading(false);
            return;
        }

        const unsubscribes: (() => void)[] = [];

        try {
            const accountsQuery = query(collection(db, 'accounts'), orderBy('code'));
            unsubscribes.push(onSnapshot(accountsQuery, snapshot => setAccounts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Account))), err => setError("Gagal mengambil data akun.")));
            const transactionsQuery = query(collection(db, 'transactions'), orderBy('date', 'desc'));
            unsubscribes.push(onSnapshot(transactionsQuery, snapshot => setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction))), err => setError("Gagal mengambil data transaksi.")));
            const assetsQuery = query(collection(db, 'assets'), orderBy('date', 'desc'));
            unsubscribes.push(onSnapshot(assetsQuery, snapshot => setAssets(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Asset))), err => setError("Gagal mengambil data aset.")));
            const settingsRef = doc(db, 'settings', 'companyInfo');
            unsubscribes.push(onSnapshot(settingsRef, doc => doc.exists() && setSettings({ id: doc.id, ...doc.data() } as CompanySettings), err => setError("Gagal mengambil data pengaturan.")));
            
            if (appUser.role === 'admin') {
                const usersQuery = query(collection(db, 'users'));
                unsubscribes.push(onSnapshot(usersQuery, snapshot => {
                    const usersData = snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as AppUser));
                    setUsers(usersData);
                }));
            } else {
                setUsers([]);
            }

        } catch (e) {
            setError("Gagal memuat data dari database.");
        } finally {
            setTimeout(() => setLoading(false), 500);
        }

        return () => unsubscribes.forEach(unsub => unsub());
    }, [appUser]);

    const addTransaction = async (transaction: Omit<Transaction, 'id'>) => {
        if (currentUser?.role === 'manager') {
            setError('Anda tidak memiliki izin untuk menambah transaksi.');
            return;
        }
        if (!db) {
            setError("Koneksi ke database tidak tersedia.");
            return;
        }
        const batch = writeBatch(db);
        const newTransactionRef = doc(collection(db, 'transactions'));
        batch.set(newTransactionRef, transaction);
        transaction.entries.forEach(entry => {
            const account = accounts.find(a => a.code === entry.account);
            if (!account) throw new Error(`Akun ${entry.account} tidak ditemukan.`);
            const accountRef = doc(db, 'accounts', account.id);
            let balanceChange = (account.type === 'Aset' || account.type === 'Beban') ? entry.debit - entry.credit : entry.credit - entry.debit;
            if(balanceChange !== 0) batch.update(accountRef, { balance: increment(balanceChange) });
        });
        await batch.commit();
    };

    const deleteTransaction = async (id: string) => {
        if (currentUser?.role !== 'admin') {
            setError('Hanya admin yang dapat menghapus transaksi.');
            return;
        }
        if (!db) {
            setError("Koneksi ke database tidak tersedia.");
            return;
        }
        const transactionRef = doc(db, 'transactions', id);
        const transactionSnap = await getDoc(transactionRef);
        if (!transactionSnap.exists()) throw new Error("Transaksi tidak ditemukan.");
        const transactionData = transactionSnap.data() as Transaction;
        const batch = writeBatch(db);
        batch.delete(transactionRef);
        transactionData.entries.forEach(entry => {
            const account = accounts.find(a => a.code === entry.account);
            if (!account) throw new Error(`Akun ${entry.account} tidak ditemukan.`);
            const accountRef = doc(db, 'accounts', account.id);
            let balanceChange = (account.type === 'Aset' || account.type === 'Beban') ? entry.credit - entry.debit : entry.debit - entry.credit;
            if (balanceChange !== 0) batch.update(accountRef, { balance: increment(balanceChange) });
        });
        await batch.commit();
    };
    
    const checkAdminAndDb = () => {
        if (!db) {
            setError("Koneksi ke database tidak tersedia.");
            return false;
        }
        if (currentUser?.role !== 'admin') {
            setError('Aksi ini memerlukan hak akses admin.');
            return false;
        }
        return true;
    }

    const addAsset = async (asset: Omit<Asset, 'id'>) => checkAdminAndDb() && await addDoc(collection(db!, 'assets'), asset);
    const updateAsset = async (id: string, asset: Omit<Asset, 'id'>) => checkAdminAndDb() && await setDoc(doc(db!, 'assets', id), asset);
    const deleteAsset = async (id: string) => checkAdminAndDb() && await deleteDoc(doc(db!, 'assets', id));
    const addAccount = async (account: Omit<Account, 'id' | 'balance'>) => checkAdminAndDb() && await addDoc(collection(db!, 'accounts'), { ...account, balance: 0 });
    const updateAccount = async (id: string, data: Omit<Account, 'id' | 'balance'>) => checkAdminAndDb() && await setDoc(doc(db!, 'accounts', id), data, { merge: true });
    const deleteAccount = async (id: string) => checkAdminAndDb() && await deleteDoc(doc(db!, 'accounts', id));

    const approveUser = async (uid: string, role: UserRole) => checkAdminAndDb() && await updateDoc(doc(db!, 'users', uid), { status: 'approved', role });
    const rejectUser = async (uid: string) => checkAdminAndDb() && await updateDoc(doc(db!, 'users', uid), { status: 'rejected' });
    const updateUserRole = async (uid: string, role: UserRole) => checkAdminAndDb() && await updateDoc(doc(db!, 'users', uid), { role });

    const value: DataContextType = { 
        accounts, transactions, assets, settings, loading, error, currentUser, users,
        addTransaction, deleteTransaction, addAsset, updateAsset, deleteAsset,
        addAccount, updateAccount, deleteAccount, approveUser, rejectUser, updateUserRole
    };

    return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};

export const useData = () => {
    const context = useContext(DataContext);
    if (context === undefined) {
        throw new Error('useData must be used within a DataProvider');
    }
    return context;
};