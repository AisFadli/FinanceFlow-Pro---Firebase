import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import { useData } from '../context/DataContext';
import { formatCurrency } from '../utils/helpers';
import { Asset } from '../types';
import AssetForm from './AssetForm';

const Assets: React.FC = () => {
    const { assets, loading, deleteAsset, currentUser } = useData();
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [assetToEdit, setAssetToEdit] = useState<Asset | null>(null);
    
    const isAdmin = currentUser?.role === 'admin';

    const handleOpenForm = (asset?: Asset) => {
        if (!isAdmin) return;
        setAssetToEdit(asset || null);
        setIsFormOpen(true);
    };

    const handleCloseForm = () => {
        setAssetToEdit(null);
        setIsFormOpen(false);
    };

    const handleDelete = (asset: Asset) => {
        if (!isAdmin) return;
        if (window.confirm(`Apakah Anda yakin ingin menghapus aset "${asset.name}"?`)) {
            deleteAsset(asset.id);
        }
    };

    return (
        <div>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                <h2 className="text-2xl md:text-3xl font-bold">Manajemen Aset</h2>
                {isAdmin && (
                    <button onClick={() => handleOpenForm()} className="bg-gradient-to-r from-primary to-secondary px-4 md:px-6 py-2 md:py-3 rounded-lg font-semibold hover:shadow-lg transition-all text-sm md:text-base w-full sm:w-auto">
                        + Aset Baru
                    </button>
                )}
            </div>

            {isFormOpen && isAdmin && ReactDOM.createPortal(
                <AssetForm assetToEdit={assetToEdit} onClose={handleCloseForm} />,
                document.getElementById('modal-root')!
            )}

            <div className="glass-effect p-4 md:p-6 rounded-xl">
                <h3 className="text-xl font-semibold mb-4">Daftar Aset</h3>
                <div className="overflow-x-auto -mx-4 md:mx-0">
                    <table className="w-full min-w-[700px]">
                        <thead>
                            <tr className="border-b border-gray-600">
                                <th className="text-left py-3 px-4">Nama Aset</th>
                                <th className="text-left py-3 px-4">Kategori</th>
                                <th className="text-right py-3 px-4">Harga Perolehan</th>
                                <th className="text-right py-3 px-4">Akum. Penyusutan</th>
                                <th className="text-right py-3 px-4">Nilai Buku</th>
                                {isAdmin && <th className="text-center py-3 px-4">Aksi</th>}
                            </tr>
                        </thead>
                        <tbody>
                            {loading ? (
                                <tr><td colSpan={isAdmin ? 6 : 5} className="text-center p-4">Memuat data aset...</td></tr>
                            ) : assets.length > 0 ? (
                                assets.map((asset: Asset) => (
                                    <tr key={asset.id} className="border-b border-gray-700 hover:bg-dark-light/30">
                                        <td className="py-3 px-4">{asset.name}</td>
                                        <td className="py-3 px-4">{asset.category}</td>
                                        <td className="py-3 px-4 text-right">{formatCurrency(asset.cost)}</td>
                                        <td className="py-3 px-4 text-right">{formatCurrency(asset.accumulatedDepreciation)}</td>
                                        <td className="py-3 px-4 text-right font-semibold">{formatCurrency(asset.cost - asset.accumulatedDepreciation)}</td>
                                        {isAdmin && (
                                            <td className="py-3 px-4 text-center space-x-2">
                                                <button onClick={() => handleOpenForm(asset)} className="text-blue-400 hover:text-blue-300 transition-colors p-1">✏️</button>
                                                <button onClick={() => handleDelete(asset)} className="text-red-400 hover:text-red-300 transition-colors p-1">🗑️</button>
                                            </td>
                                        )}
                                    </tr>
                                ))
                            ) : (
                                <tr><td className="py-4 px-4 text-center text-gray-400" colSpan={isAdmin ? 6 : 5}>Belum ada aset yang ditambahkan.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Assets;