import React, { useState, useMemo, useEffect, ChangeEvent } from 'react';
import { useData } from '../context/DataContext';
import { Account, Transaction, JournalEntry } from '../types';
import { formatCurrency, formatDate } from '../utils/helpers';

interface BankStatementItem {
    date: string;
    description: string;
    amount: number;
    originalIndex: number;
}

interface BookTransactionItem {
    id: string;
    date: string;
    desc: string;
    amount: number;
}

const Reconciliation: React.FC = () => {
    const { accounts, transactions, loading } = useData();
    const [selectedAccountCode, setSelectedAccountCode] = useState<string>('');
    
    const [unreconciledBookTxs, setUnreconciledBookTxs] = useState<BookTransactionItem[]>([]);
    const [unreconciledBankTxs, setUnreconciledBankTxs] = useState<BankStatementItem[]>([]);

    const [selectedBookTxIds, setSelectedBookTxIds] = useState<Set<string>>(new Set());
    const [selectedBankTxIndices, setSelectedBankTxIndices] = useState<Set<number>>(new Set());
    
    const [fileError, setFileError] = useState<string>('');

    const bankAccounts = useMemo(() => accounts.filter(acc => acc.type === 'Aset'), [accounts]);
    
    useEffect(() => {
        if (selectedAccountCode) {
            const relevantTransactions = transactions
                .map(tx => {
                    const entry = tx.entries.find(e => e.account === selectedAccountCode);
                    if (!entry) return null;

                    // For Asset accounts, debit is inflow (+), credit is outflow (-)
                    const amount = entry.debit - entry.credit;
                    return { id: tx.id, date: tx.date, desc: tx.desc, amount };
                })
                .filter((tx): tx is BookTransactionItem => tx !== null && tx.amount !== 0);
            
            setUnreconciledBookTxs(relevantTransactions);
        } else {
            setUnreconciledBookTxs([]);
        }
        // Reset selections when account changes
        setSelectedBookTxIds(new Set());
    }, [selectedAccountCode, transactions]);

    const handleAccountChange = (e: ChangeEvent<HTMLSelectElement>) => {
        setSelectedAccountCode(e.target.value);
        setUnreconciledBankTxs([]);
        setSelectedBankTxIndices(new Set());
        setFileError('');
    };

    const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setFileError('');
        const reader = new FileReader();

        reader.onload = (event) => {
            try {
                const text = event.target?.result as string;
                const rows = text.split('\n').slice(1); // Skip header
                const parsedData: BankStatementItem[] = rows
                    .map((row, index) => {
                        const columns = row.split(',');
                        if (columns.length < 3) return null;
                        
                        const date = new Date(columns[0].trim()).toISOString();
                        const description = columns[1].trim();
                        const amount = parseFloat(columns[2].trim());

                        if (isNaN(amount) || !date) return null;

                        return { date, description, amount, originalIndex: index };
                    })
                    .filter((item): item is BankStatementItem => item !== null);
                
                if (parsedData.length === 0) {
                    throw new Error("File tidak berisi data yang valid atau formatnya salah. Harap gunakan format: Tanggal,Deskripsi,Jumlah");
                }
                
                setUnreconciledBankTxs(parsedData);
                setSelectedBankTxIndices(new Set());
            } catch (err) {
                setFileError("Gagal memproses file. Pastikan formatnya benar (CSV: Tanggal, Deskripsi, Jumlah) dan coba lagi.");
                setUnreconciledBankTxs([]);
            }
        };
        reader.readAsText(file);
    };

    const handleToggleBookSelection = (id: string) => {
        const newSelection = new Set(selectedBookTxIds);
        if (newSelection.has(id)) {
            newSelection.delete(id);
        } else {
            newSelection.add(id);
        }
        setSelectedBookTxIds(newSelection);
    };
    
    const handleToggleBankSelection = (index: number) => {
        const newSelection = new Set(selectedBankTxIndices);
        if (newSelection.has(index)) {
            newSelection.delete(index);
        } else {
            newSelection.add(index);
        }
        setSelectedBankTxIndices(newSelection);
    };

    const { selectedBookTotal, selectedBankTotal, isMatchable } = useMemo(() => {
        const bookTotal = unreconciledBookTxs
            .filter(tx => selectedBookTxIds.has(tx.id))
            .reduce((sum, tx) => sum + tx.amount, 0);

        const bankTotal = unreconciledBankTxs
            .filter(item => selectedBankTxIndices.has(item.originalIndex))
            .reduce((sum, item) => sum + item.amount, 0);

        return {
            selectedBookTotal: bookTotal,
            selectedBankTotal: bankTotal,
            isMatchable: bookTotal === bankTotal && bookTotal !== 0 && selectedBookTxIds.size > 0
        };
    }, [selectedBookTxIds, selectedBankTxIndices, unreconciledBookTxs, unreconciledBankTxs]);
    
    const handleMatch = () => {
        setUnreconciledBookTxs(prev => prev.filter(tx => !selectedBookTxIds.has(tx.id)));
        setUnreconciledBankTxs(prev => prev.filter(item => !selectedBankTxIndices.has(item.originalIndex)));
        setSelectedBookTxIds(new Set());
        setSelectedBankTxIndices(new Set());
    };

    const summaryTotals = useMemo(() => {
        const bookTotal = unreconciledBookTxs.reduce((sum, tx) => sum + tx.amount, 0);
        const bankTotal = unreconciledBankTxs.reduce((sum, item) => sum + item.amount, 0);
        return { bookTotal, bankTotal, difference: bookTotal - bankTotal };
    }, [unreconciledBookTxs, unreconciledBankTxs]);

    const renderTransactionList = (
        items: (BookTransactionItem | BankStatementItem)[],
        selectedKeys: Set<any>,
        onToggle: (key: any) => void,
        type: 'book' | 'bank'
    ) => (
        <ul className="space-y-2 h-96 overflow-y-auto pr-2">
            {items.length > 0 ? items.map((item, idx) => {
                const key = type === 'book' ? (item as BookTransactionItem).id : (item as BankStatementItem).originalIndex;
                const isSelected = selectedKeys.has(key);
                return (
                    <li key={key} className={`flex items-start p-3 rounded-lg cursor-pointer transition-all ${isSelected ? 'bg-primary/40' : 'hover:bg-white/10'}`} onClick={() => onToggle(key)}>
                        <input type="checkbox" checked={isSelected} readOnly className="mt-1 mr-3 h-4 w-4 rounded border-gray-500 bg-transparent text-primary focus:ring-primary" />
                        <div className="flex-1">
                            <div className="flex justify-between items-center">
                                <span className="font-semibold text-sm">{'desc' in item ? item.desc : item.description}</span>
                                <span className={`font-mono text-sm ${item.amount >= 0 ? 'text-green-400' : 'text-red-400'}`}>{formatCurrency(item.amount)}</span>
                            </div>
                            <span className="text-xs text-gray-400">{formatDate(item.date)}</span>
                        </div>
                    </li>
                );
            }) : (
                <li className="text-center text-gray-400 p-6">{(type === 'bank' && !selectedAccountCode) ? "Pilih akun terlebih dahulu." : "Tidak ada data."}</li>
            )}
        </ul>
    );

    return (
        <div>
            <h2 className="text-2xl md:text-3xl font-bold mb-6">Rekonsiliasi Bank</h2>
            
            <div className="glass-effect p-4 md:p-6 rounded-xl mb-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                         <label htmlFor="account-select" className="block text-sm font-medium text-gray-300 mb-2">Pilih Akun Bank</label>
                        <select 
                            id="account-select"
                            value={selectedAccountCode} 
                            onChange={handleAccountChange}
                            className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-3 focus:ring-primary focus:border-primary"
                        >
                            <option value="" disabled>Pilih Akun Aset...</option>
                            {bankAccounts.map(acc => (
                                <option key={acc.id} value={acc.code}>
                                    {acc.code} - {acc.name}
                                </option>
                            ))}
                        </select>
                    </div>
                     <div>
                        <label htmlFor="file-upload" className="block text-sm font-medium text-gray-300 mb-2">Unggah Mutasi Bank (.csv)</label>
                        <input 
                            type="file" 
                            id="file-upload"
                            accept=".csv"
                            onChange={handleFileChange}
                            disabled={!selectedAccountCode}
                            className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-white hover:file:bg-primary/80 disabled:opacity-50"
                        />
                    </div>
                </div>
                 {fileError && <p className="text-red-400 text-sm mt-3 text-center">{fileError}</p>}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="glass-effect p-4 md:p-6 rounded-xl">
                    <h3 className="text-lg font-semibold mb-3">Transaksi Buku</h3>
                    {renderTransactionList(unreconciledBookTxs, selectedBookTxIds, handleToggleBookSelection, 'book')}
                </div>

                <div className="glass-effect p-4 md:p-6 rounded-xl">
                    <h3 className="text-lg font-semibold mb-3">Mutasi Bank</h3>
                    {renderTransactionList(unreconciledBankTxs, selectedBankTxIndices, handleToggleBankSelection, 'bank')}
                </div>
            </div>

             <div className="glass-effect p-4 md:p-6 rounded-xl mt-6">
                <h3 className="text-lg font-semibold mb-4">Ringkasan & Aksi</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                    <div className="text-center md:text-left">
                        <p className="text-sm text-gray-400">Total Buku Dipilih</p>
                        <p className={`text-lg font-semibold ${selectedBookTotal >= 0 ? 'text-green-400':'text-red-400'}`}>{formatCurrency(selectedBookTotal)}</p>
                    </div>
                     <div className="text-center md:text-left">
                        <p className="text-sm text-gray-400">Total Bank Dipilih</p>
                        <p className={`text-lg font-semibold ${selectedBankTotal >= 0 ? 'text-green-400':'text-red-400'}`}>{formatCurrency(selectedBankTotal)}</p>
                    </div>
                    <button onClick={handleMatch} disabled={!isMatchable} className="w-full bg-gradient-to-r from-accent to-cyan-600 px-6 py-3 rounded-lg font-semibold hover:shadow-lg transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                        Cocokkan Transaksi
                    </button>
                </div>
                <div className="border-t border-gray-600 mt-4 pt-4 text-center">
                    <p className="text-sm text-gray-400">Sisa Selisih</p>
                    <p className={`text-xl font-bold ${summaryTotals.difference === 0 ? 'text-green-400' : 'text-yellow-400'}`}>
                        {formatCurrency(summaryTotals.difference)}
                    </p>
                </div>
            </div>
        </div>
    );
};

export default Reconciliation;