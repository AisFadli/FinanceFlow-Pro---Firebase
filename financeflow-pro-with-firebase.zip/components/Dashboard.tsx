
import React, { useMemo } from 'react';
import { useData } from '../context/DataContext';
import { formatCurrency, formatDate } from '../utils/helpers';
import { Transaction } from '../types';

const SummaryCard: React.FC<{ title: string; value: string; icon: string; color: string; }> = ({ title, value, icon, color }) => (
    <div className="glass-effect p-4 md:p-6 rounded-xl card-hover">
        <div className="flex items-center justify-between">
            <div className="flex-1 min-w-0">
                <p className="text-gray-300 text-xs md:text-sm">{title}</p>
                <p className={`text-lg md:text-2xl font-bold ${color} truncate`}>{value}</p>
            </div>
            <div className={`w-10 h-10 md:w-12 md:h-12 ${color.replace('text-', 'bg-').replace('-400', '-500/20')} rounded-lg flex items-center justify-center ml-3`}>
                <span className={`${color} text-lg md:text-xl`}>{icon}</span>
            </div>
        </div>
    </div>
);

const Dashboard: React.FC = () => {
    const { accounts, transactions, loading } = useData();

    const summaryData = useMemo(() => {
        if (!accounts || accounts.length === 0) {
            return { totalAssets: 0, totalLiabilities: 0, totalEquity: 0, monthlyProfit: 0 };
        }
        const totalAssets = accounts.filter(acc => acc.type === 'Aset').reduce((sum, acc) => sum + acc.balance, 0);
        const totalLiabilities = accounts.filter(acc => acc.type === 'Liabilitas').reduce((sum, acc) => sum + acc.balance, 0);
        const totalEquity = accounts.filter(acc => acc.type === 'Modal').reduce((sum, acc) => sum + acc.balance, 0);

        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();
        
        const monthlyTransactions = transactions.filter(t => {
            const date = new Date(t.date);
            return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
        });

        let monthlyRevenue = 0;
        let monthlyExpenses = 0;

        monthlyTransactions.forEach(t => {
            t.entries.forEach(e => {
                const account = accounts.find(a => a.code === e.account);
                if(account){
                    if(account.type === 'Pendapatan') monthlyRevenue += e.credit;
                    if(account.type === 'Beban') monthlyExpenses += e.debit;
                }
            });
        });

        return {
            totalAssets,
            totalLiabilities,
            totalEquity,
            monthlyProfit: monthlyRevenue - monthlyExpenses
        };
    }, [accounts, transactions]);

    const recentTransactions = useMemo(() => {
        return transactions.slice(0, 5);
    }, [transactions]);
    
    const getAccountName = (code: string) => accounts.find(acc => acc.code === code)?.name || code;

    if (loading) {
        return <div className="text-center p-10">Memuat data dashboard...</div>;
    }

    return (
        <div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
                <SummaryCard title="Total Aset" value={formatCurrency(summaryData.totalAssets)} icon="💰" color="text-green-400" />
                <SummaryCard title="Total Liabilitas" value={formatCurrency(summaryData.totalLiabilities)} icon="📊" color="text-red-400" />
                <SummaryCard title="Modal" value={formatCurrency(summaryData.totalEquity)} icon="🏦" color="text-blue-400" />
                <SummaryCard title="Laba Bulan Ini" value={formatCurrency(summaryData.monthlyProfit)} icon="📈" color="text-purple-400" />
            </div>

            <div className="glass-effect p-4 md:p-6 rounded-xl mb-6 md:mb-8">
                <h3 className="text-lg md:text-xl font-semibold mb-4">Transaksi Terbaru</h3>
                <div className="overflow-x-auto -mx-4 md:mx-0">
                    <table className="w-full min-w-[600px]">
                        <thead>
                            <tr className="border-b border-gray-600">
                                <th className="text-left py-2 md:py-3 px-2 md:px-4 text-sm md:text-base">Tanggal</th>
                                <th className="text-left py-2 md:py-3 px-2 md:px-4 text-sm md:text-base">Deskripsi</th>
                                <th className="text-left py-2 md:py-3 px-2 md:px-4 text-sm md:text-base">Akun</th>
                                <th className="text-right py-2 md:py-3 px-2 md:px-4 text-sm md:text-base">Debit</th>
                                <th className="text-right py-2 md:py-3 px-2 md:px-4 text-sm md:text-base">Kredit</th>
                            </tr>
                        </thead>
                        <tbody>
                            {recentTransactions.length > 0 ? (
                                recentTransactions.flatMap((tx: Transaction, txIndex) => 
                                    tx.entries.map((entry, entryIndex) => (
                                        <tr key={`${tx.id}-${entryIndex}`} className="border-b border-gray-700">
                                            {entryIndex === 0 ? <td className="py-2 md:py-3 px-2 md:px-4" rowSpan={tx.entries.length}>{formatDate(tx.date)}</td> : null}
                                            {entryIndex === 0 ? <td className="py-2 md:py-3 px-2 md:px-4" rowSpan={tx.entries.length}>{tx.desc}</td> : null}
                                            <td className="py-2 md:py-3 px-2 md:px-4 text-gray-300 text-sm md:text-base">{getAccountName(entry.account)}</td>
                                            <td className="py-2 md:py-3 px-2 md:px-4 text-right">{entry.debit > 0 ? formatCurrency(entry.debit) : '-'}</td>
                                            <td className="py-2 md:py-3 px-2 md:px-4 text-right">{entry.credit > 0 ? formatCurrency(entry.credit) : '-'}</td>
                                        </tr>
                                    ))
                                )
                            ) : (
                                <tr className="border-b border-gray-700">
                                    <td className="py-2 md:py-3 px-2 md:px-4 text-gray-300 text-sm md:text-base" colSpan={5}>Belum ada transaksi</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
