import React, { useState, FormEvent } from 'react';
import { auth, db, createUserWithEmailAndPassword, setDoc, doc, signOut } from '../services/firebase';

interface SignUpProps {
    onSwitchView: () => void;
}

const SignUp: React.FC<SignUpProps> = ({ onSwitchView }) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [successMessage, setSuccessMessage] = useState<string | null>(null);

    const handleSignUp = async (e: FormEvent) => {
        e.preventDefault();
        if (password.length < 6) {
            setError("Password minimal harus 6 karakter.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setSuccessMessage(null);

        if (!auth || !db) {
            setError("Konfigurasi Firebase tidak lengkap. Gagal terhubung ke layanan otentikasi atau database.");
            setIsLoading(false);
            return;
        }

        try {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;

            // Create user document in Firestore
            await setDoc(doc(db, "users", user.uid), {
                name: name,
                email: user.email,
                role: 'staff', // Default role
                status: 'pending'
            });

            // Sign out the user immediately after sign up
            await signOut(auth);

            setSuccessMessage("Pendaftaran berhasil! Akun Anda menunggu persetujuan admin. Anda akan diarahkan ke halaman login...");
            setName('');
            setEmail('');
            setPassword('');
            
            setTimeout(() => {
                onSwitchView();
            }, 3000);


        } catch (err: any) {
            console.error("SignUp Error:", err); // Log the full error for debugging
            if (err.code === 'auth/email-already-in-use') {
                setError('Email ini sudah terdaftar.');
            } else if (err.code === 'permission-denied' || err.code === 'firestore/permission-denied') {
                 setError('Gagal membuat data pengguna. Periksa aturan keamanan (Security Rules) Firestore Anda untuk mengizinkan pembuatan dokumen di koleksi "users" saat pendaftaran.');
            } else {
                setError(`Terjadi kesalahan saat pendaftaran: ${err.message}`);
            }
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center px-4">
            <div className="w-full max-w-md">
                <div className="text-center mb-8">
                     <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                        Buat Akun Baru
                    </h1>
                    <p className="text-gray-400 mt-1">FinanceFlow Pro - Koperasi An Nahl</p>
                </div>

                <div className="glass-effect p-8 rounded-2xl">
                    <form onSubmit={handleSignUp} className="space-y-6">
                        {successMessage ? (
                             <div className="bg-green-500/20 border border-green-500 text-green-300 p-3 rounded-lg text-center text-sm">
                                {successMessage}
                            </div>
                        ) : (
                            <>
                                <div>
                                    <label htmlFor="name" className="block text-sm font-medium text-gray-300">Nama Lengkap</label>
                                    <input id="name" name="name" type="text" required value={name} onChange={(e) => setName(e.target.value)} className="mt-1 w-full bg-dark-light/50 border border-gray-600 rounded-lg p-3 focus:ring-primary focus:border-primary"/>
                                </div>
                                <div>
                                    <label htmlFor="email-signup" className="block text-sm font-medium text-gray-300">Email</label>
                                    <input id="email-signup" name="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 w-full bg-dark-light/50 border border-gray-600 rounded-lg p-3 focus:ring-primary focus:border-primary"/>
                                </div>
                                <div>
                                    <label htmlFor="password-signup" className="block text-sm font-medium text-gray-300">Password</label>
                                    <input id="password-signup" name="password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="mt-1 w-full bg-dark-light/50 border border-gray-600 rounded-lg p-3 focus:ring-primary focus:border-primary"/>
                                </div>

                                {error && (
                                    <div className="bg-red-500/20 border border-red-500 text-red-300 p-3 rounded-lg text-center text-sm">
                                        {error}
                                    </div>
                                )}
                                
                                <div>
                                    <button type="submit" disabled={isLoading} className="w-full flex justify-center py-3 px-4 rounded-lg text-sm font-medium text-white bg-gradient-to-r from-primary to-secondary hover:from-primary/90 disabled:opacity-50 transition-all">
                                        {isLoading ? 'Mendaftar...' : 'Daftar'}
                                    </button>
                                </div>
                            </>
                        )}
                    </form>
                     <p className="mt-6 text-center text-sm text-gray-400">
                        Sudah punya akun?{' '}
                        <button onClick={onSwitchView} className="font-medium text-primary hover:text-primary/80">
                            Login di sini
                        </button>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default SignUp;