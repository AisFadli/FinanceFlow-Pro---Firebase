
import React, { useState, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { Account } from '../types';
import { formatCurrency, formatDate } from '../utils/helpers';

interface LedgerEntry {
    date: string;
    ref: string;
    desc: string;
    debit: number;
    credit: number;
    balance: number;
}

const Ledger: React.FC = () => {
    const { accounts, transactions, loading } = useData();
    const [selectedAccountCode, setSelectedAccountCode] = useState<string>('');

    const handleAccountChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setSelectedAccountCode(e.target.value);
    };

    const selectedAccount = useMemo((): Account | undefined => {
        return accounts.find(acc => acc.code === selectedAccountCode);
    }, [accounts, selectedAccountCode]);

    const ledgerData = useMemo(() => {
        if (!selectedAccountCode || !selectedAccount) {
            return { entries: [], totalDebit: 0, totalCredit: 0, finalBalance: 0 };
        }

        const relevantTransactions = transactions
            .filter(t => t.entries.some(e => e.account === selectedAccountCode))
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

        let runningBalance = 0;
        const entries: LedgerEntry[] = [];
        let totalDebit = 0;
        let totalCredit = 0;

        for (const tx of relevantTransactions) {
            for (const entry of tx.entries) {
                if (entry.account === selectedAccountCode) {
                    runningBalance += entry.debit - entry.credit;
                    totalDebit += entry.debit;
                    totalCredit += entry.credit;
                    entries.push({
                        date: tx.date,
                        ref: tx.ref,
                        desc: tx.desc,
                        debit: entry.debit,
                        credit: entry.credit,
                        balance: runningBalance,
                    });
                }
            }
        }
        
        return { entries, totalDebit, totalCredit, finalBalance: runningBalance };
    }, [selectedAccountCode, transactions, selectedAccount]);

    return (
        <div>
            <h2 className="text-2xl md:text-3xl font-bold mb-6">Buku Besar</h2>
            
            <div className="glass-effect p-4 md:p-6 rounded-xl mb-6">
                <h3 className="text-lg font-semibold mb-4">Pilih Akun</h3>
                <select 
                    value={selectedAccountCode} 
                    onChange={handleAccountChange}
                    className="w-full md:w-1/2 bg-dark-light/50 border border-gray-600 rounded-lg p-3 focus:ring-primary focus:border-primary"
                    aria-label="Pilih Akun Buku Besar"
                >
                    <option value="" disabled>Pilih Akun untuk melihat riwayat...</option>
                    {accounts.map(acc => (
                        <option key={acc.id} value={acc.code}>
                            {acc.code} - {acc.name}
                        </option>
                    ))}
                </select>
            </div>

            <div className="glass-effect p-4 md:p-6 rounded-xl">
                {selectedAccount ? (
                     <div>
                        <div className="pb-4 mb-4 border-b border-gray-600">
                            <h3 className="text-xl font-bold">{selectedAccount.code} - {selectedAccount.name}</h3>
                            <p className="text-gray-400">{selectedAccount.type}</p>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6 text-center">
                            <div className="glass-effect p-3 rounded-lg">
                                <p className="text-sm text-gray-400">Total Debit</p>
                                <p className="text-lg font-semibold text-green-400">{formatCurrency(ledgerData.totalDebit)}</p>
                            </div>
                            <div className="glass-effect p-3 rounded-lg">
                                <p className="text-sm text-gray-400">Total Kredit</p>
                                <p className="text-lg font-semibold text-red-400">{formatCurrency(ledgerData.totalCredit)}</p>
                            </div>
                            <div className="glass-effect p-3 rounded-lg col-span-2 md:col-span-1">
                                <p className="text-sm text-gray-400">Saldo Akhir</p>
                                <p className="text-lg font-semibold">{formatCurrency(ledgerData.finalBalance)}</p>
                            </div>
                        </div>

                        <div className="overflow-x-auto -mx-4 md:mx-0">
                            <table className="w-full min-w-[700px]">
                                <thead>
                                    <tr className="border-b border-gray-600">
                                        <th className="text-left py-3 px-4">Tanggal</th>
                                        <th className="text-left py-3 px-4">Referensi</th>
                                        <th className="text-left py-3 px-4">Deskripsi</th>
                                        <th className="text-right py-3 px-4">Debit</th>
                                        <th className="text-right py-3 px-4">Kredit</th>
                                        <th className="text-right py-3 px-4">Saldo</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {loading ? (
                                        <tr><td colSpan={6} className="text-center p-6">Memuat data...</td></tr>
                                    ) : ledgerData.entries.length > 0 ? (
                                        ledgerData.entries.map((entry, index) => (
                                            <tr key={index} className="border-b border-gray-700 hover:bg-dark-light/30">
                                                <td className="py-3 px-4">{formatDate(entry.date)}</td>
                                                <td className="py-3 px-4 font-mono">{entry.ref}</td>
                                                <td className="py-3 px-4">{entry.desc}</td>
                                                <td className="py-3 px-4 text-right">{entry.debit > 0 ? formatCurrency(entry.debit) : '-'}</td>
                                                <td className="py-3 px-4 text-right">{entry.credit > 0 ? formatCurrency(entry.credit) : '-'}</td>
                                                <td className="py-3 px-4 text-right font-semibold">{formatCurrency(entry.balance)}</td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr><td colSpan={6} className="text-center p-6 text-gray-400">Tidak ada transaksi untuk akun ini.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                ) : (
                    <div className="text-center p-10">
                        <p className="text-gray-400">Silakan pilih akun dari daftar di atas untuk melihat buku besarnya.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Ledger;
