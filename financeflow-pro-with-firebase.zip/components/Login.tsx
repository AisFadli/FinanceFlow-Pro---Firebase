import React, { useState, FormEvent } from 'react';
import { auth, signInWithEmailAndPassword } from '../services/firebase';

interface LoginProps {
    onSwitchView: () => void;
    error: string | null;
    setError: (error: string | null) => void;
}

const Login: React.FC<LoginProps> = ({ onSwitchView, error, setError }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleLogin = async (e: FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError(null);

        try {
            await signInWithEmailAndPassword(auth, email, password);
            // onAuthStateChanged in App.tsx will now handle success and failure cases, including DB checks.
        } catch (err: any) {
            switch (err.code) {
                case 'auth/invalid-email':
                    setError('Format email tidak valid.');
                    break;
                case 'auth/user-not-found':
                case 'auth/wrong-password':
                case 'auth/invalid-credential':
                    setError('Email atau password salah.');
                    break;
                default:
                    setError('Terjadi kesalahan saat login. Silakan coba lagi.');
                    break;
            }
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if(error) setError(null);
        setEmail(e.target.value);
    }
    const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if(error) setError(null);
        setPassword(e.target.value);
    }

    return (
        <div className="min-h-screen flex items-center justify-center px-4">
            <div className="w-full max-w-md">
                <div className="text-center mb-8">
                    <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center mx-auto mb-4">
                        <span className="text-white font-bold text-3xl">FF</span>
                    </div>
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                        FinanceFlow Pro
                    </h1>
                    <p className="text-gray-400 mt-1">Koperasi An Nahl</p>
                </div>

                <div className="glass-effect p-8 rounded-2xl">
                    <form onSubmit={handleLogin} className="space-y-6">
                        <div>
                            <label htmlFor="email" className="block text-sm font-medium text-gray-300">
                                Email
                            </label>
                            <div className="mt-1">
                                <input
                                    id="email"
                                    name="email"
                                    type="email"
                                    autoComplete="email"
                                    required
                                    value={email}
                                    onChange={handleEmailChange}
                                    className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-3 focus:ring-primary focus:border-primary transition-all"
                                    placeholder="anda@email.com"
                                />
                            </div>
                        </div>

                        <div>
                            <label htmlFor="password" className="block text-sm font-medium text-gray-300">
                                Password
                            </label>
                            <div className="mt-1">
                                <input
                                    id="password"
                                    name="password"
                                    type="password"
                                    autoComplete="current-password"
                                    required
                                    value={password}
                                    onChange={handlePasswordChange}
                                    className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-3 focus:ring-primary focus:border-primary transition-all"
                                    placeholder="••••••••"
                                />
                            </div>
                        </div>

                        {error && (
                            <div className="bg-red-500/20 border border-red-500 text-red-300 p-3 rounded-lg text-center text-sm">
                                {error}
                            </div>
                        )}

                        <div>
                            <button
                                type="submit"
                                disabled={isLoading}
                                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark focus:ring-primary disabled:opacity-50 disabled:cursor-wait transition-all"
                            >
                                {isLoading ? 'Memproses...' : 'Login'}
                            </button>
                        </div>
                    </form>
                     <p className="mt-6 text-center text-sm text-gray-400">
                        Belum punya akun?{' '}
                        <button onClick={onSwitchView} className="font-medium text-primary hover:text-primary/80">
                            Daftar di sini
                        </button>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default Login;