import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { Transaction } from '../types';
import { formatCurrency, formatDate } from '../utils/helpers';
import TransactionForm from './TransactionForm';

const TransactionList: React.FC = () => {
    const { transactions, loading, deleteTransaction, accounts, currentUser } = useData();

    const getAccountName = (code: string) => accounts.find(acc => acc.code === code)?.name || code;

    const handleDelete = (id: string, desc: string) => {
        if (window.confirm(`Apakah Anda yakin ingin menghapus transaksi "${desc}"?`)) {
            deleteTransaction(id);
        }
    };

    if (loading) {
        return <div className="text-center p-10">Memuat transaksi...</div>;
    }

    return (
         <div className="glass-effect p-4 md:p-6 rounded-xl">
            <h3 className="text-lg md:text-xl font-semibold mb-4">Daftar Transaksi</h3>
            <div className="overflow-x-auto -mx-4 md:mx-0">
                <table className="w-full min-w-[700px]">
                    <thead>
                        <tr className="border-b border-gray-600">
                            <th className="text-left py-2 px-4">Tanggal</th>
                            <th className="text-left py-2 px-4">Referensi</th>
                            <th className="text-left py-2 px-4">Deskripsi</th>
                            <th className="text-right py-2 px-4">Total</th>
                            <th className="text-center py-2 px-4">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        {transactions.length > 0 ? (
                            transactions.map((tx) => {
                                const total = tx.entries.reduce((sum, entry) => sum + entry.debit, 0);
                                return (
                                <tr key={tx.id} className="border-b border-gray-700 hover:bg-dark-light/30">
                                    <td className="py-3 px-4">{formatDate(tx.date)}</td>
                                    <td className="py-3 px-4 font-mono">{tx.ref}</td>
                                    <td className="py-3 px-4">{tx.desc}</td>
                                    <td className="py-3 px-4 text-right font-mono">{formatCurrency(total)}</td>
                                    <td className="py-3 px-4 text-center">
                                        {currentUser?.role === 'admin' && (
                                            <button onClick={() => handleDelete(tx.id, tx.desc)} className="text-red-400 hover:text-red-300 transition-colors">
                                                🗑️
                                            </button>
                                        )}
                                    </td>
                                </tr>
                                )
                            })
                        ) : (
                            <tr>
                                <td colSpan={5} className="text-center py-6 text-gray-400">Belum ada transaksi yang dicatat.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

const Transactions: React.FC = () => {
    const { currentUser } = useData();
    const [showForm, setShowForm] = useState(false);

    const canAddTransaction = currentUser?.role === 'admin' || currentUser?.role === 'staff';

    return (
        <div>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                <h2 className="text-2xl md:text-3xl font-bold">Pencatatan Transaksi</h2>
                {canAddTransaction && (
                    <button onClick={() => setShowForm(!showForm)} className="bg-gradient-to-r from-primary to-secondary px-4 md:px-6 py-2 md:py-3 rounded-lg font-semibold hover:shadow-lg transition-all text-sm md:text-base w-full sm:w-auto">
                        {showForm ? 'Tutup Form' : '+ Transaksi Baru'}
                    </button>
                )}
            </div>

            {showForm && canAddTransaction && <TransactionForm onFormSubmit={() => setShowForm(false)} onCancel={() => setShowForm(false)} />}
            
            <div className="mt-8">
                 <TransactionList />
            </div>
        </div>
    );
};

export default Transactions;