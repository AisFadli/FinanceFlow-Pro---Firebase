import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { Asset } from '../types';

interface AssetFormProps {
    assetToEdit: Asset | null;
    onClose: () => void;
}

const AssetForm: React.FC<AssetFormProps> = ({ assetToEdit, onClose }) => {
    const { addAsset, updateAsset } = useData();
    const [formData, setFormData] = useState<Omit<Asset, 'id' | 'accumulatedDepreciation'>>({
        name: '',
        category: '',
        cost: 0,
        date: new Date().toISOString().split('T')[0],
        life: 5,
        residual: 0,
        method: 'straight-line',
        isDepreciable: true,
    });
    const [error, setError] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        if (assetToEdit) {
            const { id, accumulatedDepreciation, ...editableData } = assetToEdit;
            setFormData(editableData);
        }
    }, [assetToEdit]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        
        let processedValue: string | number | boolean = value;
        if (type === 'number') {
            processedValue = parseFloat(value) || 0;
        }
        if (name === 'isDepreciable') {
             processedValue = (e.target as HTMLInputElement).checked;
        }

        setFormData(prev => ({ ...prev, [name]: processedValue }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.name.trim() || formData.cost <= 0) {
            setError('Nama Aset dan Harga Perolehan (lebih dari 0) wajib diisi.');
            return;
        }
        setIsSubmitting(true);
        setError('');

        try {
            const assetData = { ...formData, accumulatedDepreciation: assetToEdit?.accumulatedDepreciation || 0 };
            if (assetToEdit) {
                await updateAsset(assetToEdit.id, assetData);
            } else {
                await addAsset(assetData);
            }
            onClose();
        } catch (err) {
            setError('Gagal menyimpan aset. Coba lagi.');
        } finally {
            setIsSubmitting(false);
        }
    };
    
    return (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={onClose}>
            <div className="glass-effect p-6 md:p-8 rounded-xl w-full max-w-lg mx-4" onClick={e => e.stopPropagation()}>
                <form onSubmit={handleSubmit}>
                    <h3 className="text-xl font-semibold mb-6">{assetToEdit ? 'Edit Aset' : 'Tambah Aset Baru'}</h3>
                    
                    {error && <div className="bg-red-500/20 text-red-300 p-3 rounded-lg mb-4">{error}</div>}

                    <div className="space-y-4">
                        <div>
                            <label htmlFor="name" className="block text-sm mb-1 text-gray-300">Nama Aset</label>
                            <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                        </div>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="category" className="block text-sm mb-1 text-gray-300">Kategori</label>
                                <input type="text" name="category" id="category" value={formData.category} onChange={handleChange} className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                            </div>
                             <div>
                                <label htmlFor="date" className="block text-sm mb-1 text-gray-300">Tanggal Perolehan</label>
                                <input type="date" name="date" id="date" value={formData.date} onChange={handleChange} required className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                            </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="cost" className="block text-sm mb-1 text-gray-300">Harga Perolehan</label>
                                <input type="number" name="cost" id="cost" value={formData.cost} onChange={handleChange} required className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                            </div>
                             <div>
                                <label htmlFor="residual" className="block text-sm mb-1 text-gray-300">Nilai Residu</label>
                                <input type="number" name="residual" id="residual" value={formData.residual} onChange={handleChange} className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                            </div>
                        </div>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="life" className="block text-sm mb-1 text-gray-300">Masa Manfaat (tahun)</label>
                                <input type="number" name="life" id="life" value={formData.life} onChange={handleChange} className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                            </div>
                            <div>
                                <label htmlFor="method" className="block text-sm mb-1 text-gray-300">Metode Penyusutan</label>
                                <select name="method" id="method" value={formData.method} onChange={handleChange} className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary">
                                    <option value="straight-line">Garis Lurus</option>
                                    <option value="declining-balance">Saldo Menurun</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div className="flex justify-end gap-4 mt-8">
                        <button type="button" onClick={onClose} className="bg-gray-700 hover:bg-gray-800 px-6 py-2 rounded-lg font-semibold transition-all">Batal</button>
                        <button type="submit" disabled={isSubmitting} className="bg-primary hover:bg-primary/80 px-6 py-2 rounded-lg font-semibold transition-all disabled:opacity-50">
                            {isSubmitting ? 'Menyimpan...' : 'Simpan'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AssetForm;
