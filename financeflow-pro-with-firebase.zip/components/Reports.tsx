
import React, { useState, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { formatCurrency, formatDate } from '../utils/helpers';
import { Account } from '../types';

type ReportType = 'neraca' | 'laba-rugi';

const ReportHeader: React.FC<{ title: string; companyName: string }> = ({ title, companyName }) => (
    <div className="mb-6 text-center">
        <h3 className="text-xl md:text-2xl font-bold">{companyName}</h3>
        <h4 className="text-lg md:text-xl font-semibold">{title}</h4>
        <p className="text-gray-400">Untuk Periode yang Berakhir pada {formatDate(new Date().toISOString())}</p>
    </div>
);

const ReportRow: React.FC<{ label: string; value: number; isTotal?: boolean; indent?: boolean }> = ({ label, value, isTotal = false, indent = false }) => (
    <div className={`flex justify-between py-2 border-b border-gray-700 ${isTotal ? 'font-bold' : ''} ${indent ? 'pl-4' : ''}`}>
        <span className={isTotal ? 'text-white' : 'text-gray-300'}>{label}</span>
        <span>{formatCurrency(value)}</span>
    </div>
);

const Reports: React.FC = () => {
    const [activeReport, setActiveReport] = useState<ReportType | null>(null);
    const { accounts, transactions, settings, loading } = useData();

    const reportData = useMemo(() => {
        if (loading || accounts.length === 0) return null;

        const accountBalances = new Map<string, number>();
        accounts.forEach(acc => accountBalances.set(acc.code, 0));

        transactions.forEach(tx => {
            tx.entries.forEach(entry => {
                const account = accounts.find(a => a.code === entry.account);
                if (!account) return;

                const currentBalance = accountBalances.get(entry.account) || 0;
                let balanceChange = 0;
                
                if (account.type === 'Aset' || account.type === 'Beban') {
                    balanceChange = entry.debit - entry.credit;
                } else {
                    balanceChange = entry.credit - entry.debit;
                }
                accountBalances.set(entry.account, currentBalance + balanceChange);
            });
        });

        const getAccountsWithBalances = (type: Account['type']) =>
            accounts
                .filter(acc => acc.type === type)
                .map(acc => ({ ...acc, balance: accountBalances.get(acc.code) || 0 }))
                .filter(acc => acc.balance !== 0);

        const revenues = getAccountsWithBalances('Pendapatan');
        const expenses = getAccountsWithBalances('Beban');
        const totalRevenue = revenues.reduce((sum, acc) => sum + acc.balance, 0);
        const totalExpense = expenses.reduce((sum, acc) => sum + acc.balance, 0);
        const netIncome = totalRevenue - totalExpense;

        const assets = getAccountsWithBalances('Aset');
        const liabilities = getAccountsWithBalances('Liabilitas');
        const equities = getAccountsWithBalances('Modal');
        const totalAssets = assets.reduce((sum, acc) => sum + acc.balance, 0);
        const totalLiabilities = liabilities.reduce((sum, acc) => sum + acc.balance, 0);
        const totalEquities = equities.reduce((sum, acc) => sum + acc.balance, 0);
        const totalLiabilitiesAndEquity = totalLiabilities + totalEquities + netIncome;

        return {
            incomeStatement: { revenues, expenses, totalRevenue, totalExpense, netIncome },
            balanceSheet: { assets, liabilities, equities, netIncome, totalAssets, totalLiabilities, totalEquities, totalLiabilitiesAndEquity },
        };
    }, [accounts, transactions, loading]);

    const renderContent = () => {
        if (loading) return <div className="text-center p-10">Menghitung laporan...</div>;
        if (!reportData) return <div className="text-center p-10 text-gray-400">Data tidak cukup untuk membuat laporan.</div>;

        const companyName = settings?.name || 'Perusahaan Anda';
        
        switch(activeReport) {
            case 'laba-rugi': {
                const { revenues, expenses, totalRevenue, totalExpense, netIncome } = reportData.incomeStatement;
                return (
                    <div className="printable-area">
                        <ReportHeader title="Laporan Laba Rugi" companyName={companyName} />
                        <div className="space-y-4">
                            <div>
                                <h5 className="font-semibold text-lg mb-2">Pendapatan</h5>
                                {revenues.map(acc => <ReportRow key={acc.id} label={acc.name} value={acc.balance} indent />)}
                                <ReportRow label="Total Pendapatan" value={totalRevenue} isTotal />
                            </div>
                            <div>
                                <h5 className="font-semibold text-lg mt-6 mb-2">Beban</h5>
                                {expenses.map(acc => <ReportRow key={acc.id} label={acc.name} value={acc.balance} indent />)}
                                <ReportRow label="Total Beban" value={totalExpense} isTotal />
                            </div>
                            <div className={`flex justify-between py-3 mt-4 text-lg font-bold ${netIncome >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                <span>Laba Bersih</span>
                                <span>{formatCurrency(netIncome)}</span>
                            </div>
                        </div>
                    </div>
                );
            }
            case 'neraca': {
                const { assets, liabilities, equities, netIncome, totalAssets, totalLiabilitiesAndEquity } = reportData.balanceSheet;
                return (
                    <div className="printable-area">
                         <ReportHeader title="Laporan Posisi Keuangan (Neraca)" companyName={companyName} />
                         <div className="grid grid-cols-1 md:grid-cols-2 md:gap-8">
                             <div>
                                 <h5 className="font-semibold text-lg mb-2">Aset</h5>
                                 {assets.map(acc => <ReportRow key={acc.id} label={acc.name} value={acc.balance} />)}
                                 <ReportRow label="Total Aset" value={totalAssets} isTotal />
                             </div>
                             <div className="mt-6 md:mt-0">
                                 <h5 className="font-semibold text-lg mb-2">Liabilitas</h5>
                                 {liabilities.map(acc => <ReportRow key={acc.id} label={acc.name} value={acc.balance} />)}
                                 <h5 className="font-semibold text-lg mt-6 mb-2">Modal</h5>
                                 {equities.map(acc => <ReportRow key={acc.id} label={acc.name} value={acc.balance} />)}
                                 <ReportRow label="Laba Ditahan" value={netIncome} />
                                 <ReportRow label="Total Liabilitas dan Modal" value={totalLiabilitiesAndEquity} isTotal />
                             </div>
                         </div>
                    </div>
                );
            }
            default:
                return (
                    <div className="text-center p-10">
                        <p className="text-gray-400">Silakan pilih laporan yang ingin Anda lihat.</p>
                    </div>
                );
        }
    }

    return (
        <div>
            <h2 className="text-2xl md:text-3xl font-bold mb-6">Laporan Keuangan</h2>
            
            <div className="no-print grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
                <button onClick={() => setActiveReport('neraca')} className={`glass-effect p-6 rounded-xl card-hover text-left ${activeReport === 'neraca' ? 'ring-2 ring-primary' : ''}`}>
                    <span className="text-2xl mr-3">⚖️</span>
                    <h3 className="text-xl font-semibold">Neraca</h3>
                </button>
                <button onClick={() => setActiveReport('laba-rugi')} className={`glass-effect p-6 rounded-xl card-hover text-left ${activeReport === 'laba-rugi' ? 'ring-2 ring-primary' : ''}`}>
                    <span className="text-2xl mr-3">📈</span>
                    <h3 className="text-xl font-semibold">Laba Rugi</h3>
                </button>
                 <button className="glass-effect p-6 rounded-xl card-hover text-left opacity-50 cursor-not-allowed">
                    <span className="text-2xl mr-3">💰</span>
                    <h3 className="text-xl font-semibold">Arus Kas</h3>
                </button>
                 <button className="glass-effect p-6 rounded-xl card-hover text-left opacity-50 cursor-not-allowed">
                    <span className="text-2xl mr-3">📊</span>
                    <h3 className="text-xl font-semibold">Neraca Saldo</h3>
                </button>
            </div>

            <div className="glass-effect p-4 md:p-6 rounded-xl">
                 {activeReport && (
                    <div className="flex justify-end mb-4 no-print">
                        <button onClick={() => window.print()} className="bg-primary hover:bg-primary/80 px-4 py-2 rounded-lg transition-all font-semibold">
                            🖨️ Cetak Laporan
                        </button>
                    </div>
                )}
                {renderContent()}
            </div>
        </div>
    );
};

export default Reports;
