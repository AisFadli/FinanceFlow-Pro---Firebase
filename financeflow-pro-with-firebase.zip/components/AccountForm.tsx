import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { Account } from '../types';

interface AccountFormProps {
    accountToEdit: Account | null;
    onClose: () => void;
}

const accountTypes: Account['type'][] = ['Aset', 'Liabilitas', 'Modal', 'Pendapatan', 'Beban'];

const AccountForm: React.FC<AccountFormProps> = ({ accountToEdit, onClose }) => {
    const { addAccount, updateAccount, accounts } = useData();
    const [formData, setFormData] = useState<Omit<Account, 'id' | 'balance'>>({
        code: '',
        name: '',
        type: 'Aset',
        description: '',
    });
    const [error, setError] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        if (accountToEdit) {
            const { id, balance, ...editableData } = accountToEdit;
            setFormData(editableData);
        }
    }, [accountToEdit]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.code.trim() || !formData.name.trim()) {
            setError('Kode dan Nama Akun wajib diisi.');
            return;
        }

        const isCodeDuplicate = accounts.some(
            acc => acc.code === formData.code && acc.id !== accountToEdit?.id
        );
        if (isCodeDuplicate) {
            setError(`Kode akun "${formData.code}" sudah digunakan. Mohon gunakan kode unik.`);
            return;
        }

        setIsSubmitting(true);
        setError('');

        try {
            if (accountToEdit) {
                await updateAccount(accountToEdit.id, formData);
            } else {
                await addAccount(formData);
            }
            onClose();
        } catch (err) {
            setError('Gagal menyimpan akun. Coba lagi.');
        } finally {
            setIsSubmitting(false);
        }
    };
    
    return (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={onClose}>
            <div className="glass-effect p-6 md:p-8 rounded-xl w-full max-w-md mx-4" onClick={e => e.stopPropagation()}>
                <form onSubmit={handleSubmit}>
                    <h3 className="text-xl font-semibold mb-6">{accountToEdit ? 'Edit Akun' : 'Tambah Akun Baru'}</h3>
                    
                    {error && <div className="bg-red-500/20 text-red-300 p-3 rounded-lg mb-4 text-sm">{error}</div>}

                    <div className="space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="code" className="block text-sm mb-1 text-gray-300">Kode Akun</label>
                                <input type="text" name="code" id="code" value={formData.code} onChange={handleChange} required className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                            </div>
                            <div>
                                <label htmlFor="type" className="block text-sm mb-1 text-gray-300">Tipe Akun</label>
                                <select name="type" id="type" value={formData.type} onChange={handleChange} className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary">
                                    {accountTypes.map(type => <option key={type} value={type}>{type}</option>)}
                                </select>
                            </div>
                        </div>
                        <div>
                            <label htmlFor="name" className="block text-sm mb-1 text-gray-300">Nama Akun</label>
                            <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                        </div>
                         <div>
                            <label htmlFor="description" className="block text-sm mb-1 text-gray-300">Deskripsi (Opsional)</label>
                            <textarea name="description" id="description" value={formData.description} onChange={handleChange} rows={3} className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary"></textarea>
                        </div>
                    </div>

                    <div className="flex justify-end gap-4 mt-8">
                        <button type="button" onClick={onClose} className="bg-gray-700 hover:bg-gray-800 px-6 py-2 rounded-lg font-semibold transition-all">Batal</button>
                        <button type="submit" disabled={isSubmitting} className="bg-primary hover:bg-primary/80 px-6 py-2 rounded-lg font-semibold transition-all disabled:opacity-50">
                            {isSubmitting ? 'Menyimpan...' : 'Simpan'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AccountForm;
