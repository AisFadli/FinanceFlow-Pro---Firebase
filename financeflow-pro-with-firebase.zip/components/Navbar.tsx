import React, { useState } from 'react';
import { Section } from '../types';

interface NavbarProps {
    activeSection: Section;
    onSectionChange: (section: Section) => void;
    onLogout: () => void;
}

const navItems: { id: Section; label: string }[] = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'transactions', label: 'Transaksi' },
    { id: 'ledger', label: 'Buku Besar' },
    { id: 'reconciliation', label: 'Rekonsiliasi Bank' },
    { id: 'assets', label: 'Aset' },
    { id: 'reports', label: 'Laporan' },
    { id: 'settings', label: 'Pengaturan' },
];

const Navbar: React.FC<NavbarProps> = ({ activeSection, onSectionChange, onLogout }) => {
    const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);

    const handleNavClick = (section: Section) => {
        onSectionChange(section);
        if (isMobileMenuOpen) {
            setMobileMenuOpen(false);
        }
    };

    const handleLogoutClick = () => {
        onLogout();
        if (isMobileMenuOpen) {
            setMobileMenuOpen(false);
        }
    }

    return (
        <nav className="glass-effect p-4 mb-4 md:mb-8 sticky top-0 z-50">
            <div className="max-w-7xl mx-auto">
                <div className="flex justify-between items-center mb-4 md:mb-0">
                    <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 md:w-10 md:h-10 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                            <span className="text-white font-bold text-sm md:text-lg">FF</span>
                        </div>
                        <h1 className="text-lg md:text-2xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                            FinanceFlow Pro - Koperasi An Nahl
                        </h1>
                    </div>
                    <button onClick={() => setMobileMenuOpen(!isMobileMenuOpen)} className="md:hidden text-white p-2">
                        <span>{isMobileMenuOpen ? '✕' : '☰'}</span>
                    </button>
                </div>
                <div className={`${isMobileMenuOpen ? 'flex' : 'hidden'} md:flex md:justify-center md:space-x-6`}>
                    <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-6 w-full md:w-auto items-center">
                        {navItems.map(item => (
                            <button
                                key={item.id}
                                onClick={() => handleNavClick(item.id)}
                                className={`px-4 py-3 md:py-2 rounded-lg hover:bg-white/10 transition-all text-left md:text-center w-full md:w-auto ${activeSection === item.id ? 'bg-white/20' : ''}`}
                            >
                                {item.label}
                            </button>
                        ))}
                        <button
                            onClick={handleLogoutClick}
                            className="px-4 py-3 md:py-2 rounded-lg hover:bg-red-500/20 text-red-400 transition-all text-left md:text-center w-full md:w-auto"
                        >
                            Logout
                        </button>
                    </div>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
