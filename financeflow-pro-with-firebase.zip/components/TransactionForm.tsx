import React, { useState, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { JournalEntry, Transaction } from '../types';

interface TransactionFormProps {
    onFormSubmit: () => void;
    onCancel: () => void;
}

const TransactionForm: React.FC<TransactionFormProps> = ({ onFormSubmit, onCancel }) => {
    const { accounts, addTransaction } = useData();
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [desc, setDesc] = useState('');
    const [ref, setRef] = useState('');
    const [entries, setEntries] = useState<JournalEntry[]>([
        { account: '', debit: 0, credit: 0 },
        { account: '', debit: 0, credit: 0 },
    ]);
    const [error, setError] = useState('');

    const handleEntryChange = (index: number, field: keyof JournalEntry, value: string | number) => {
        const newEntries = [...entries];
        if (typeof value === 'string' && field === 'account') {
            newEntries[index][field] = value;
        } else if (typeof value === 'string') {
            const numValue = parseFloat(value) || 0;
            if (field === 'debit') {
                newEntries[index].debit = numValue;
                newEntries[index].credit = 0;
            } else {
                newEntries[index].credit = numValue;
                newEntries[index].debit = 0;
            }
        }
        setEntries(newEntries);
    };

    const addEntryRow = () => {
        setEntries([...entries, { account: '', debit: 0, credit: 0 }]);
    };

    const removeEntryRow = (index: number) => {
        const newEntries = entries.filter((_, i) => i !== index);
        setEntries(newEntries);
    };

    const { totalDebit, totalCredit, isBalanced } = useMemo(() => {
        const totalDebit = entries.reduce((sum, entry) => sum + entry.debit, 0);
        const totalCredit = entries.reduce((sum, entry) => sum + entry.credit, 0);
        return {
            totalDebit,
            totalCredit,
            isBalanced: totalDebit === totalCredit && totalDebit > 0,
        };
    }, [entries]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (!desc.trim()) {
            setError('Deskripsi tidak boleh kosong.');
            return;
        }
        if (entries.some(e => !e.account)) {
            setError('Setiap baris entri harus memiliki akun yang dipilih.');
            return;
        }
        if (!isBalanced) {
            setError('Total Debit dan Kredit harus seimbang dan tidak boleh nol.');
            return;
        }

        const newTransaction: Omit<Transaction, 'id'> = {
            date,
            desc,
            ref,
            entries: entries.filter(e => e.debit > 0 || e.credit > 0), // Hanya simpan entri yg relevan
        };

        await addTransaction(newTransaction);
        onFormSubmit();
    };

    return (
        <div className="glass-effect p-6 rounded-xl mb-8">
            <form onSubmit={handleSubmit}>
                <h3 className="text-xl font-semibold mb-6">Form Jurnal Umum</h3>
                
                {error && <div className="bg-red-500/20 border border-red-500 text-red-300 p-3 rounded-lg mb-4">{error}</div>}

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div>
                        <label htmlFor="date" className="block text-sm mb-1 text-gray-300">Tanggal</label>
                        <input type="date" id="date" value={date} onChange={e => setDate(e.target.value)} required className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                    </div>
                     <div>
                        <label htmlFor="desc" className="block text-sm mb-1 text-gray-300">Deskripsi</label>
                        <input type="text" id="desc" value={desc} onChange={e => setDesc(e.target.value)} required className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                    </div>
                     <div>
                        <label htmlFor="ref" className="block text-sm mb-1 text-gray-300">No. Referensi (Opsional)</label>
                        <input type="text" id="ref" value={ref} onChange={e => setRef(e.target.value)} className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                    </div>
                </div>

                {/* Entries Table */}
                <div className="overflow-x-auto -mx-6">
                     <table className="w-full min-w-[600px] text-sm">
                        <thead>
                            <tr className="border-b border-t border-gray-600">
                                <th className="text-left p-2 w-2/5">Akun</th>
                                <th className="text-right p-2">Debit</th>
                                <th className="text-right p-2">Kredit</th>
                                <th className="p-2 w-12"></th>
                            </tr>
                        </thead>
                        <tbody>
                            {entries.map((entry, index) => (
                                <tr key={index}>
                                    <td className="p-2">
                                        <select value={entry.account} onChange={e => handleEntryChange(index, 'account', e.target.value)} className="w-full bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary">
                                            <option value="" disabled>Pilih Akun...</option>
                                            {accounts.map(acc => <option key={acc.id} value={acc.code}>{acc.code} - {acc.name}</option>)}
                                        </select>
                                    </td>
                                    <td className="p-2">
                                        <input type="number" step="any" min="0" value={entry.debit} onChange={e => handleEntryChange(index, 'debit', e.target.value)} className="w-full text-right bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                                    </td>
                                    <td className="p-2">
                                        <input type="number" step="any" min="0" value={entry.credit} onChange={e => handleEntryChange(index, 'credit', e.target.value)} className="w-full text-right bg-dark-light/50 border border-gray-600 rounded-lg p-2 focus:ring-primary focus:border-primary" />
                                    </td>
                                    <td className="p-2 text-center">
                                        {entries.length > 2 && <button type="button" onClick={() => removeEntryRow(index)} className="text-red-400 hover:text-red-300">✕</button>}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                        <tfoot>
                            <tr className={`border-t border-gray-600 font-bold ${isBalanced ? 'text-green-400' : 'text-red-400'}`}>
                                <td className="p-2 text-right">Total</td>
                                <td className="p-2 text-right">Rp {totalDebit.toLocaleString('id-ID')}</td>
                                <td className="p-2 text-right">Rp {totalCredit.toLocaleString('id-ID')}</td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <div className="flex justify-between items-center mt-6">
                    <button type="button" onClick={addEntryRow} className="bg-gray-600 hover:bg-gray-700 px-4 py-2 rounded-lg font-semibold transition-all text-sm">
                        + Tambah Baris
                    </button>
                    <div className="flex gap-4">
                        <button type="button" onClick={onCancel} className="bg-gray-700 hover:bg-gray-800 px-6 py-3 rounded-lg font-semibold transition-all">
                            Batal
                        </button>
                         <button type="submit" disabled={!isBalanced} className="bg-gradient-to-r from-primary to-secondary px-6 py-3 rounded-lg font-semibold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed">
                            Simpan Transaksi
                        </button>
                    </div>
                </div>
            </form>
        </div>
    );
};

export default TransactionForm;
