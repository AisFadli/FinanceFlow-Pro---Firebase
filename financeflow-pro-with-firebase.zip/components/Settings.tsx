import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import { useData } from '../context/DataContext';
import { Account, AppUser, UserRole } from '../types';
import { formatCurrency } from '../utils/helpers';
import AccountForm from './AccountForm';

const UserManagement: React.FC = () => {
    const { users, approveUser, rejectUser, updateUserRole, currentUser } = useData();
    const [editingRoles, setEditingRoles] = useState<Record<string, UserRole>>({});

    const handleRoleChange = (uid: string, role: UserRole) => {
        setEditingRoles(prev => ({ ...prev, [uid]: role }));
    };

    const handleApprove = (uid: string) => {
        const role = editingRoles[uid] || 'staff'; // Default to staff if not selected
        approveUser(uid, role);
    };

    const handleUpdateRole = (uid: string) => {
        const role = editingRoles[uid];
        if (role) {
            updateUserRole(uid, role);
        }
    };
    
    return (
        <div className="glass-effect p-6 rounded-xl col-span-1 lg:col-span-2">
             <h3 className="text-xl font-semibold mb-4">Manajemen Pengguna</h3>
             <div className="overflow-x-auto -mx-6 px-6">
                <table className="w-full text-sm">
                    <thead>
                        <tr className="border-b border-gray-600">
                            <th className="text-left py-2 px-2">Nama</th>
                            <th className="text-left py-2 px-2">Email</th>
                            <th className="text-left py-2 px-2">Status</th>
                            <th className="text-left py-2 px-2">Peran</th>
                            <th className="text-center py-2 px-2">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.filter(u => u.uid !== currentUser?.uid).map(user => (
                            <tr key={user.uid} className="border-b border-gray-700 hover:bg-dark-light/30">
                                <td className="py-3 px-2">{user.name}</td>
                                <td className="py-3 px-2">{user.email}</td>
                                <td className="py-3 px-2">
                                    <span className={`px-2 py-1 rounded-full text-xs ${
                                        user.status === 'approved' ? 'bg-green-500/20 text-green-300' :
                                        user.status === 'pending' ? 'bg-yellow-500/20 text-yellow-300' :
                                        'bg-red-500/20 text-red-300'
                                    }`}>
                                        {user.status}
                                    </span>
                                </td>
                                <td className="py-3 px-2">
                                     {user.status === 'approved' ? (
                                        <select
                                            value={editingRoles[user.uid] || user.role}
                                            onChange={(e) => handleRoleChange(user.uid, e.target.value as UserRole)}
                                            className="bg-dark-light/50 border border-gray-600 rounded-md p-1"
                                        >
                                            <option value="staff">Staf</option>
                                            <option value="manager">Manajer</option>
                                            <option value="admin">Admin</option>
                                        </select>
                                    ) : user.role }
                                </td>
                                <td className="py-3 px-2 text-center space-x-2">
                                    {user.status === 'pending' && (
                                        <>
                                            <select 
                                                defaultValue="staff"
                                                onChange={(e) => handleRoleChange(user.uid, e.target.value as UserRole)}
                                                className="bg-dark-light/50 border border-gray-600 rounded-md p-1 text-xs"
                                            >
                                                 <option value="staff">Staf</option>
                                                 <option value="manager">Manajer</option>
                                                 <option value="admin">Admin</option>
                                            </select>
                                            <button onClick={() => handleApprove(user.uid)} className="text-green-400 hover:text-green-300">Approve</button>
                                            <button onClick={() => rejectUser(user.uid)} className="text-red-400 hover:text-red-300">Reject</button>
                                        </>
                                    )}
                                    {user.status === 'approved' && (
                                        <button onClick={() => handleUpdateRole(user.uid)} disabled={!editingRoles[user.uid] || editingRoles[user.uid] === user.role} className="text-blue-400 hover:text-blue-300 disabled:opacity-50">Save Role</button>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
        </div>
    );
}


const Settings: React.FC = () => {
    const { settings, accounts, loading, deleteAccount, currentUser } = useData();
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [accountToEdit, setAccountToEdit] = useState<Account | null>(null);

    const isAdmin = currentUser?.role === 'admin';

    const handleOpenForm = (account?: Account) => {
        if (!isAdmin) return;
        setAccountToEdit(account || null);
        setIsFormOpen(true);
    };

    const handleCloseForm = () => {
        setAccountToEdit(null);
        setIsFormOpen(false);
    };

    const handleDelete = (account: Account) => {
        if (!isAdmin) return;
        if (account.isDefault) {
            alert("Akun default tidak dapat dihapus.");
            return;
        }
        if (window.confirm(`Apakah Anda yakin ingin menghapus akun "${account.code} - ${account.name}"?`)) {
            deleteAccount(account.id);
        }
    };

    return (
        <div>
            {isFormOpen && isAdmin && ReactDOM.createPortal(
                <AccountForm accountToEdit={accountToEdit} onClose={handleCloseForm} />,
                document.getElementById('modal-root')!
            )}

            <h2 className="text-2xl md:text-3xl font-bold mb-6">Pengaturan Sistem</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
                <div className="glass-effect p-6 rounded-xl">
                    <h3 className="text-xl font-semibold mb-4">Informasi Perusahaan</h3>
                    {loading ? <p>Memuat pengaturan...</p> : settings ? (
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-400">Nama Perusahaan</label>
                                <p className="text-lg text-white">{settings.name}</p>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-400">Alamat</label>
                                <p className="text-white">{settings.address}</p>
                            </div>
                             <p className="text-gray-400 pt-4">Form untuk mengedit informasi ini akan diimplementasikan di sini.</p>
                        </div>
                    ) : <p>Belum ada informasi perusahaan.</p>}
                </div>

                <div className="glass-effect p-6 rounded-xl flex flex-col">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-semibold">Chart of Accounts</h3>
                        {isAdmin && <button onClick={() => handleOpenForm()} className="bg-accent hover:bg-accent/80 px-4 py-2 rounded-lg transition-all font-semibold text-sm">+ Akun Baru</button>}
                    </div>
                    
                    <div className="flex-grow overflow-y-auto -mx-6 px-6">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="border-b border-gray-600">
                                    <th className="text-left py-2 px-2">Kode</th>
                                    <th className="text-left py-2 px-2">Nama Akun</th>
                                    <th className="text-left py-2 px-2">Tipe</th>
                                    {isAdmin && <th className="text-center py-2 px-2">Aksi</th>}
                                </tr>
                            </thead>
                            <tbody>
                                {loading ? (
                                    <tr><td colSpan={isAdmin ? 4 : 3} className="text-center p-4">Memuat akun...</td></tr>
                                ) : accounts.length > 0 ? (
                                    accounts.map((account: Account) => (
                                        <tr key={account.id} className="border-b border-gray-700 hover:bg-dark-light/30">
                                            <td className="py-2 px-2 font-mono">{account.code}</td>
                                            <td className="py-2 px-2">{account.name}</td>
                                            <td className="py-2 px-2">{account.type}</td>
                                            {isAdmin && 
                                                <td className="py-2 px-2 text-center space-x-1">
                                                    <button onClick={() => handleOpenForm(account)} className="text-blue-400 hover:text-blue-300 p-1">✏️</button>
                                                    <button onClick={() => handleDelete(account)} className={`p-1 ${account.isDefault ? 'opacity-30 cursor-not-allowed' : 'text-red-400 hover:text-red-300'}`} disabled={account.isDefault}>🗑️</button>
                                                </td>
                                            }
                                        </tr>
                                    ))
                                ) : (
                                    <tr><td className="py-4 px-2 text-center text-gray-400" colSpan={isAdmin ? 4 : 3}>Belum ada akun yang dibuat.</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
                {isAdmin && <UserManagement />}
            </div>
        </div>
    );
};

export default Settings;