import React, { useState, useCallback, useEffect } from 'react';
import { DataProvider, useData } from './context/DataContext';
import { Section, AppUser } from './types';
import { auth, onAuthStateChanged, signOut, User, isFirebaseConfigured, db, doc, getDoc } from './services/firebase';

import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import Transactions from './components/Transactions';
import Ledger from './components/Ledger';
import Reconciliation from './components/Reconciliation';
import Assets from './components/Assets';
import Reports from './components/Reports';
import Settings from './components/Settings';
import Login from './components/Login';
import SignUp from './components/SignUp';
import LoadingScreen from './components/LoadingScreen';

const ErrorDisplay: React.FC = () => {
    const { error } = useData();

    if (!error) {
        return null;
    }

    return (
        <div className="glass-effect p-4 mb-6 border border-red-500/50 text-center" role="alert">
            <p className="text-red-400 font-semibold">
                <span className="font-bold">Terjadi Kesalahan:</span> {error}
            </p>
        </div>
    );
};

const MainAppContent: React.FC = () => {
    const [activeSection, setActiveSection] = useState<Section>('dashboard');

    const handleSectionChange = useCallback((section: Section) => {
        setActiveSection(section);
    }, []);

    const handleLogout = async () => {
        if (!auth) return;
        try {
            await signOut(auth);
        } catch (error) {
            console.error("Error signing out: ", error);
        }
    };

    const renderSection = () => {
        switch (activeSection) {
            case 'dashboard':
                return <Dashboard />;
            case 'transactions':
                return <Transactions />;
            case 'ledger':
                return <Ledger />;
            case 'reconciliation':
                return <Reconciliation />;
            case 'assets':
                return <Assets />;
            case 'reports':
                return <Reports />;
            case 'settings':
                return <Settings />;
            default:
                return <Dashboard />;
        }
    };

    return (
        <>
            <Navbar activeSection={activeSection} onSectionChange={handleSectionChange} onLogout={handleLogout} />
            <main className="max-w-7xl mx-auto px-4">
                <ErrorDisplay />
                {renderSection()}
            </main>
        </>
    );
};

interface MainAppProps {
    appUser: AppUser;
}
const MainApp: React.FC<MainAppProps> = ({ appUser }) => {
    return (
        <DataProvider appUser={appUser}>
            <MainAppContent/>
        </DataProvider>
    )
}

const App: React.FC = () => {
    const [appUser, setAppUser] = useState<AppUser | null>(null);
    const [authLoading, setAuthLoading] = useState(true);
    const [authView, setAuthView] = useState<'login' | 'signup'>('login');
    const [configError, setConfigError] = useState<string | null>(null);
    const [loginError, setLoginError] = useState<string | null>(null);

    useEffect(() => {
        if (!isFirebaseConfigured) {
            setConfigError("Konfigurasi Firebase tidak lengkap. Silakan edit file 'services/firebase.ts' dan isi dengan kredensial proyek Firebase Anda.");
            setAuthLoading(false);
            return;
        }

        if (!auth) {
            setConfigError("Gagal menginisialisasi Firebase. Periksa konsol untuk detailnya.");
            setAuthLoading(false);
            return;
        }

        const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
            if (currentUser) {
                setLoginError(null); 
                try {
                    if (!db) {
                        throw new Error("Firestore is not initialized.");
                    }
                    const userDocRef = doc(db, 'users', currentUser.uid);
                    const userDocSnap = await getDoc(userDocRef);

                    if (userDocSnap.exists()) {
                        const fetchedAppUser = { uid: currentUser.uid, ...userDocSnap.data() } as AppUser;
                        
                        if (fetchedAppUser.status === 'pending') {
                            setLoginError('Akun Anda sedang menunggu persetujuan admin.');
                            if (auth) await signOut(auth);
                        } else if (fetchedAppUser.status === 'rejected') {
                            setLoginError('Pendaftaran akun Anda telah ditolak.');
                            if (auth) await signOut(auth);
                        } else {
                            setAppUser(fetchedAppUser);
                        }
                    } else {
                        setLoginError('Data pengguna tidak ditemukan. Silakan hubungi admin.');
                        if (auth) await signOut(auth);
                    }
                } catch (err: any) {
                    console.error("Firestore connection/read error:", err);
                    if (err.code === 'unavailable') {
                         setLoginError('Gagal terhubung ke Firestore. Pastikan Anda telah membuat database Cloud Firestore di Firebase Console dan periksa koneksi internet Anda.');
                    } else {
                         setLoginError(`Terjadi kesalahan saat mengambil data pengguna: ${err.message}`);
                    }
                    if (auth) await signOut(auth);
                }
            } else {
                setAppUser(null);
            }
            setAuthLoading(false);
        });
        return () => unsubscribe();
    }, []);

    if (authLoading) {
        return <LoadingScreen />;
    }
    
    if (configError) {
        return (
            <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white font-sans">
                <div className="w-full max-w-lg text-center">
                    <div className="glass-effect p-8 rounded-2xl">
                        <h1 className="text-2xl font-bold text-red-400 mb-4">Kesalahan Konfigurasi</h1>
                        <p className="text-gray-300">{configError}</p>
                    </div>
                </div>
            </div>
        );
    }

    if (appUser) {
        return <MainApp appUser={appUser} />;
    }

    if (authView === 'login') {
        return <Login onSwitchView={() => setAuthView('signup')} error={loginError} setError={setLoginError} />;
    }
    return <SignUp onSwitchView={() => setAuthView('login')} />;
};

export default App;